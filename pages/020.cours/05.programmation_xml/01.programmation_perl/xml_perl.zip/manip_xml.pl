#! /usr/bin/perl

# --------------------------------------------
# UNIVERSITÉ PARIS OUEST NANTERRE LA DÉFENSE
# MASTER 2 DEFI 
# COURS DE DOCUMENT STRUCTURÉ
# J-P JORDA
# --------------------------------------------
# Exemple de manipulation d'un document XML 
# en Perl, en utilisant les modules XML::LibXML
# et XML::LibXSLT
# Ce programme :
# * "Parse" le document XML contenu dans le 
#   fichier 'exemple.xml' (il vérifie donc qu'il
#   est bien formé)
# * Applique la feuille de style 'exemple_xslt.xsl'
#   au document et récupère le résultat de la 
#   transformation
# * Modifie ce résultat en remplaçant le texte
#   par des éléments 
#   <prenom> et <nom_fam> 
# Chacune de ces opérations est réalisée dans 
# une fonction différente.
# --------------------------------------------
# Voir aussi : 
# * perldoc XML::LibXML
# * perldoc XML::LibXSLT
# * perldoc XML::LibXML::Node
# * perldoc XML::LibXML::Parser
# * perldoc XML::LibXML::Element
# --------------------------------------------

use strict;
use utf8; # pour préciser que ce script est composé avec un éditeur UTF-8
# Chargement des wrappers pour libxml2 et libxslt :
use XML::LibXML; 
use XML::LibXSLT;

my $XML_FILE  = 'exemple.xml';
my $XSLT_FILE = 'exemple_xslt.xsl';

my $Parser = undef ; # Parser XML::LibXML. Instancié dans le programme principal
my  $Stylesheet = undef ; # Voir programme princial : va permettre la transformation XSLT avec la feuille de style 'exemple_xslt_.xsl'


# -------------------
# PROGRAMME PRINCIPAL
# -------------------

# Instanciation des objets nécessaire au traitement

my $Parser = XML::LibXML->new();
$Parser->line_numbers(1) ; # En cas de problème, affichera le numéro de ligne
                           # où l'erreur s'est produite


# On instancie un objet XML::LibXSLT, puis on parse la feuille de style
my $xslt = XML::LibXSLT->new();
my $style_doc = $Parser->parse_file($XSLT_FILE);
$Stylesheet = $xslt->parse_stylesheet_file($XSLT_FILE);

# $Parser et $Stylesheet sont des variables globales : on va les utiliser 
# dans les fonctions.

my $doc = parse_fichier($XML_FILE); # fonction définie plus bas
my $result = applique_xslt($doc);
my $new_doc = modifie_xml($result);

# on met le résultat final dans un fichier 'exemple_final.xml'
$new_doc->toFile('exemple_final.xml', 1);


# ---------
# FONCTIONS
# ---------

sub parse_fichier{
    my $fichier = shift ;
    my $doc = $Parser->parse_file($fichier);
    return $doc ;


}

sub applique_xslt{
    my $doc_in  = shift ;
    my $doc_out =  $Stylesheet->transform($doc_in);
    return $doc_out;
}

sub modifie_xml{
    my $doc_in = shift ;
    my $doc_out = $doc_in->cloneNode(1); # on duplique le document
                                         # Ici n'et pas utile, ca on ne fait
                                         # plur rien du document d'entrée
    # recherche des noeuds 'nom'
    my @nodes = $doc_out->findnodes('//nom');
    # pour chacun des noeuds, on récupère la 
    # valeur, on décompose, et on remplace
    # le texte par les nouveaux noeuds
    # PLUS DE DETAILS : perldoc XML::LibXML::Node
    foreach my $node (@nodes){
	my $nom = $node->textContent;
	# décomposition (simpliste) en prénom/nom famille
	my ($prenom,$fam) = split('\s+',$nom);
	# remplacement du noeud texte par deux nouveaux noeuds
	# 1- création des noeuds
	my $n_prenom = XML::LibXML::Element->new('prenom');
	my $n_fam    = XML::LibXML::Element->new('nom_fam');
	$n_prenom->appendText($prenom);
	$n_fam->appendText($fam);
	# 2 - suppression du noeud texte (en fait de tous les noeud fils)
	for my $n_child ($node->childNodes){
	    $node->removeChild($n_child);
	}
	# 3- ajout des nouveaux éléments
	$node->appendChild($n_prenom);
	$node->appendChild($n_fam);
    }
    return $doc_out;
}
