#! /usr/bin/perl

# Ce programme applique la feuille de style contenu dans le fichier 
# "outils2html.xsl"
# au document XML contenu dans le fichier "outils_xml.xml"
# Voir :
# http://search.cpan.org/perldoc?XML::LibXSLT
# http://search.cpan.org/perldoc?XML::LibXML
# http://search.cpan.org/perldoc?XML::LibXML::Parser
# http://search.cpan.org/perldoc?XML::LibXML::Node
# http://search.cpan.org/perldoc?XML::LibXML::Element
# etc.




use utf8;
use strict;
use XML::LibXML;
use XML::LibXSLT;

# "Parsing" du document XML
# Ce qui suit devrait marcher y compris avec les modules un peu ancien
# De nouvelle méthode avec une syntaxe différente existe pour les version récente
# Voir perldoc XML::LibXML::Parser ou http://search.cpan.org/perldoc?XML::LibXML::Parser

my $parser = XML::LibXML->new();
my $doc = $parser->parse_file("outils_xml.xml");

# Parsing de la feuille de style
my $style_doc = $parser->parse_file("outils2html.xsl");

# Instanciation de la transformation (à faire 1x)
my $xslto = XML::LibXSLT->new();
my $xslt = $xslto->parse_stylesheet($style_doc);

# application de la transformation
my $result = $xslt->transform($doc);

# Sauvegarde dans un fichier
$result->toFile("result.html",1);
