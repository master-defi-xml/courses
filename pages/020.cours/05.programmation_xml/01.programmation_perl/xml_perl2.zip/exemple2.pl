#! /usr/bin/perl

# Création noeud par noeud du XML suivant :
# <couleurs>
#    <couleur rgb="FF0000">rouge</couleur>
#    <couleur rgb='00FF00">vert</couleur>
# </couleurs>

# Pour en savoir plus : voir la doc Perl
# dans une console :
# perldoc XML::LibXML
# perldoc XML::LibXML::Parser
# perldoc XML::LibXML::Node
# perldoc XML::LibXML::Element
# etc...
# Ou sur http://search.cpan.org

use utf8;
use XML::LibXML;
use XML::LibXSLT;
use strict;


# Construction du document et de son élément racine
my $doc = XML::LibXML::Document->new('1.0','utf-8');
my $root = $doc->createElement('couleurs');
$doc->setDocumentElement($root);

# Construction des éléments 'couleur'
my $node1 = $doc->createElement('couleur');
$node1->setAttribute('rgb','FF0000');
$node1->appendText('rouge');
$root->addChild($node1);
my $node2 = $doc->createElement('couleur');
$node2->setAttribute('rgb','00FF00');
$node2->appendText('vert');
$root->addChild($node2);
# Sauvegarde dans un fichier 'couleurs.xml'
$doc->toFile('couleurs.xml',1);
