#! /usr/bin/perl

use strict ;
use Encode::Detect::Detector;
use File::Slurp ;

my @Files = @ARGV;
for my $file (@Files) {
    my $data = File::Slurp::read_file($file);
    my $charset = Encode::Detect::Detector::detect($data);
    print "$file : Encodage = $charset\n" ;
}
